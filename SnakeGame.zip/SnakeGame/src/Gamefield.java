import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;


public class Gamefield extends JPanel implements ActionListener{
    private final int SIZE = 500;
    private final int DOT_SIZE=20;
    private final int ALL_DOTS=600;
    private Image dot;
    private Image dot1;
    private Image dot2;
    private Image dot3;
    private Image dot4;
    private Image dot5;
    private Image dot6;
    private Image d1;
    private Image d2;
    private Image d3;
    private Image d4;
    private Image d5;
    private Image d6;
    private Image apple;
    private Image go;
    private Image play;
    private Image ap;
    private Image snk;
    private Image ch;
    private Image fc;
    private Image ret;
    private Image app2;
    private Image app3;
    private int appleX;
    private int appleY;
    private int app2X;
    private int app2Y;
    private int app3X;
    private int app3Y;
    private final int[] x = new int[ALL_DOTS];
    private final int[] y = new int[ALL_DOTS];
    private int dots;
    private Timer timer;
    private boolean left = false;
    private boolean right = true;
    private boolean up = false;
    private boolean down = false;
    private boolean inGame = false;
    private boolean toStart = true;
    private boolean choose = false;
    public static Audio a_sound;
    public static Audio a_bit;
    public static Audio a_go;
    public static Audio a_click;


    public void soudMusic(){
        a_sound = new Audio("sound.wav");
        a_sound.sound();
        a_bit = new Audio("applebit.wav");
        a_go = new Audio("gameover.wav");
        a_click = new Audio("click.wav");
    }

    public Gamefield(){
        setBackground(new Color(0,255,161));
        loadImages();
        initGame();
        addKeyListener(new FieldKeyListener());
        setFocusable(true);
        soudMusic();

    }

    public void initGame(){
        dots = 3;
        for (int i=0; i<dots; i++){
            x[i]=60 - i*(DOT_SIZE-1);
            y[i]=60;
        }
        timer = new Timer(250,this);
        timer.start();
        createApple();
        createApp2();
        createApp3();
    }

    public void createApple(){
        appleX = new Random().nextInt(25)*DOT_SIZE;
        appleY = new Random().nextInt(25)*DOT_SIZE;

    }
    public void createApp2(){
        app2X = new Random().nextInt(25)*DOT_SIZE;
        app2Y = new Random().nextInt(25)*DOT_SIZE;

    }
    public void createApp3(){
        app3X = new Random().nextInt(25)*DOT_SIZE;
        app3Y = new Random().nextInt(25)*DOT_SIZE;

    }

    public void loadImages(){
        ImageIcon iia = new ImageIcon("apple.png");
        apple = iia.getImage();
        ImageIcon iid1 = new ImageIcon("snake1.png");
        dot1 = iid1.getImage();
        ImageIcon iigo = new ImageIcon("gameover.png");
        go = iigo.getImage();
        ImageIcon iip = new ImageIcon("play.png");
        play = iip.getImage();
        ImageIcon iiap = new ImageIcon("app.png");
        ap = iiap.getImage();
        ImageIcon iisnk = new ImageIcon("snk.png");
        snk = iisnk.getImage();
        ImageIcon iid2 = new ImageIcon("snake2.png");
        dot2 = iid2.getImage();
        ImageIcon iid3 = new ImageIcon("snake3.png");
        dot3 = iid3.getImage();
        ImageIcon iid4 = new ImageIcon("snake4.png");
        dot4 = iid4.getImage();
        ImageIcon iid5 = new ImageIcon("snake5.png");
        dot5 = iid5.getImage();
        ImageIcon iid6 = new ImageIcon("snake6.png");
        dot6 = iid6.getImage();
        ImageIcon iidd1 = new ImageIcon("1.png");
        d1 = iidd1.getImage();
        ImageIcon iidd2 = new ImageIcon("2.png");
        d2 = iidd2.getImage();
        ImageIcon iidd3 = new ImageIcon("3.png");
        d3 = iidd3.getImage();
        ImageIcon iidd4 = new ImageIcon("4.png");
        d4 = iidd4.getImage();
        ImageIcon iidd5 = new ImageIcon("5.png");
        d5 = iidd5.getImage();
        ImageIcon iidd6 = new ImageIcon("6.png");
        d6 = iidd6.getImage();
        ImageIcon iich = new ImageIcon("ch.png");
        ch = iich.getImage();
        ImageIcon iifc = new ImageIcon("fc.png");
        fc = iifc.getImage();
        ImageIcon iiret = new ImageIcon("ret.png");
        ret = iiret.getImage();
        ImageIcon iiapp2 = new ImageIcon("apple2.png");
        app2 = iiapp2.getImage();
        ImageIcon iiapp3 = new ImageIcon("apple3.png");
        app3 = iiapp3.getImage();
    }

        @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if(toStart && ! inGame && !choose) {
            g.drawImage(snk, 25, 40,this);
            g.drawImage(play,80,180,this);
            g.drawImage(ap, 25,350,this);

        }
        if(choose){
            g.drawImage(ch, 100, 40, this);
            g.drawImage(fc, 80,170,this);
            g.drawImage(d1, 73, 257, this);
            g.drawImage(d2, 203, 257, this);
            g.drawImage(d3, 333, 257, this);
            g.drawImage(d4, 73, 327, this);
            g.drawImage(d5, 203, 327, this);
            g.drawImage(d6, 333, 327, this);
                    for (int i=0; i<3; i++) {
                        g.drawImage(dot1, 100+22*i, 260, this);
                        g.drawImage(dot2, 230+22*i, 260, this);
                        g.drawImage(dot3, 360+22*i, 260, this);
                        g.drawImage(dot4, 100+22*i, 330, this);
                        g.drawImage(dot5, 230+22*i, 330, this);
                        g.drawImage(dot6, 360+22*i, 330, this);
                    }
            }

        if(! toStart){
            inGame=false;
            g.drawImage(ap, 25, 40, this);
            g.drawImage(go,100,165,this);
            g.drawImage(ret, 70,380,this);
        }
        if(inGame){
            g.drawImage(apple,appleX,appleY,this);
            g.drawImage(app2,app2X,app2Y,this);
            g.drawImage(app3,app3X,app3Y,this);
            for (int i=0; i<dots; i++){
                g.drawImage(dot,x[i],y[i],this);
            }
        }


    }

    public void move(){
        for (int i = dots; i>0; i--) {
            x[i]=x[i-1];
            y[i]=y[i-1];
        }
        if(left){
            x[0] -= DOT_SIZE;
        }
        if(right){
            x[0] += DOT_SIZE;
        }
        if(up){
            y[0] -= DOT_SIZE;
        }
        if(down){
            y[0] += DOT_SIZE;
        }
    }



    public void checkApple(){
        if(x[0]==appleX && y[0] == appleY){
            a_bit.sound();
            dots++;
            createApple();
        }
    }

    public void checkApp2(){
        if(x[0]==app2X && y[0] == app2Y){
            a_bit.sound();
            dots++;
            createApp2();
        }
    }

    public void checkApp3(){
        if(x[0]==app3X && y[0] == app3Y){
            a_bit.sound();
            dots++;
            createApp3();
        }
    }

    public void checkCollissions(){
        for (int i = dots; i>0; i--){
            if (i>4 && x[0]==x[i]&& y[0]==y[i]){
                a_go.sound();
                toStart = false;

            }
        }
        if(x[0]>SIZE){
            a_go.sound();
            toStart = false;
        }
        if(x[0]<0){
            a_go.sound();
            toStart = false;
        }
        if(y[0]>SIZE){
            a_go.sound();
            toStart = false;
        }
        if(y[0]<0){
            a_go.sound();
            toStart = false;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (inGame&&toStart){
            checkApple();
            checkApp2();
            checkApp3();
            checkCollissions();
            move();

        }
        repaint();
    }

    class FieldKeyListener extends KeyAdapter {
        @Override

        public void keyPressed(KeyEvent e) {
            super.keyPressed(e);
            int key = e.getKeyCode();
            if (toStart){
                if (key == KeyEvent.VK_ENTER){
                    a_click.sound();
                    choose=true;
                }
            }
            if (choose){
                if (key==KeyEvent.VK_1){
                    a_click.sound();
                    dot=dot1;
                    choose=false;
                    inGame=true;
                }
                if (key==KeyEvent.VK_2){
                    a_click.sound();
                    dot=dot2;
                    choose=false;
                    inGame=true;
                }
                if (key==KeyEvent.VK_3){
                    a_click.sound();
                    dot=dot3;
                    choose=false;
                    inGame=true;
                }
                if (key==KeyEvent.VK_4){
                    a_click.sound();
                    dot=dot4;
                    choose=false;
                    inGame=true;
                }
                if (key==KeyEvent.VK_5){
                    a_click.sound();
                    dot=dot5;
                    choose=false;
                    inGame=true;
                }
                if (key==KeyEvent.VK_6){
                    a_click.sound();
                    dot=dot6;
                    choose=false;
                    inGame=true;
                }
            }
            if (! toStart && ! inGame){
                if (key == KeyEvent.VK_ENTER){
                    a_click.sound();
                toStart=true;
                dots=3;
                x[0] = 100;
                y[0] = 100;
                }
            }
            if (key == KeyEvent.VK_LEFT && ! right){
                left = true;
                up=false;
                down=false;
            }
            if (key == KeyEvent.VK_RIGHT && ! left){
                right = true;
                up=false;
                down=false;
            }
            if (key == KeyEvent.VK_UP && ! down){
                up = true;
                right=false;
                left=false;
            }
            if (key == KeyEvent.VK_DOWN && ! up){
                down = true;
                right=false;
                left=false;
            }
        }
    }
}
