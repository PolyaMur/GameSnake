import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;

public class Audio {
    private final String track;
    private Clip clip = null;

    public Audio (String track){
        this.track = track;
    }

    public void sound(){
        File f = new File(this.track);
        AudioInputStream tr =null;
        try {
            tr = AudioSystem.getAudioInputStream(f);
        } catch (UnsupportedAudioFileException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            clip = AudioSystem.getClip();
            clip.open(tr);
            clip.setFramePosition(0);
            clip.start();
            if(track.equals("sound.wav")){
                clip.loop(Clip.LOOP_CONTINUOUSLY);
            }
        } catch (LineUnavailableException e) {
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }

    }


}
